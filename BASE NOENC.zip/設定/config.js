module.exports = {
  BOT_TOKEN: "TOKENS",
  OWNER_ID: ["5126860596"],
};